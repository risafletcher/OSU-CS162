/*******************************************************************************
** Author:       Risa Fletcher
** Date:         12/10/19
** Description:  An abstract class for each room
*******************************************************************************/
#ifndef SPACE_HPP
#define SPACE_HPP
#include "utilities.hpp"

enum Location
{
    BATHROOM,
    STAIRWELL,
    LIBRARY,
    HALL,
    RECEPTION,
    DINING
};

enum Item
{
    TOILET_SNAKE,
    SERVER_CLOTHES,
    KEY,
    SALAD,
    NOTE,
    WIG
};

class Space
{
    protected:
        Location name;
        Space   *top,
                *right,
                *bottom,
                *left;
        Item *items;
        int numberOfItems;

    public:
        Space();
        Space(Space *top, Space *right, Space *bottom, Space *left);
        ~Space();
        void play();
        Item *getItems();
        void removeItem(Item);
        void setItem(Item *);
        Space *getTop();
        Space *getRight();
        Space *getBottom();
        Space *getLeft();
        Location getName();
        virtual void showMenu();
};

#endif