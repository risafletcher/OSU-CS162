/*******************************************************************************
** Author:       Risa Fletcher
** Date:         12/10/19
** Description:  A derived room class
*******************************************************************************/
#include "Reception.hpp"
#include "Space.hpp"
#include "Player.hpp"
#include <iostream>

using std::cin;
using std::cout;
using std::endl;

Reception::Reception() : Space()
{
    name = RECEPTION;
    *items = {NOTE};
    numberOfItems = 1;
}

Reception::Reception(Space *top, Space *right, Space *bottom, Space *left) : 
Space(top, right, bottom, left)
{
}

void Reception::checkDesks()
{
    cout << "You checked the library desks and found nothing." << endl;
}

void Reception::checkBeneathRug()
{
    cout << "You checked beneath the rug and found nothing." << endl;
}

void Reception::checkCoatPockets(Player *player)
{
    cout << "You found a very controversial note from Putin. Perhaps Melania ";
    cout << "would like to see this!" << endl;
    pickUpItem(player, NOTE);
}

void Reception::pickUpItem(Player *player, Item item)
{
    bool foundMatch = false;
    for (int i; i < numberOfItems; ++i)
    {
        if (items[i] == item)
        {
            player->addItem(items[i]);
            foundMatch = true;
        }
        if (foundMatch)
        {
            items[i] = items[i + 1];
            numberOfItems--;
        }
    }
}

void Reception::showMenu(Player *player)
{
    string options[3] = {
        "Check desks",
        "Check coat pockets",
        "Check beneath rug"};

    int menuChoice = menu(options, 3);

    switch (menuChoice)
    {
    case 0:
        checkDesks();
    case 1:
        checkCoatPockets(player);
    case 3:
        checkBeneathRug();
    default:
        break;
    }
}
