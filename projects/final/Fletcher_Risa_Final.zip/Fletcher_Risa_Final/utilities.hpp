/*******************************************************************************
** Author:       Risa Fletcher
** Date:         12/10/19
** Description:  Utility functions for the game
*******************************************************************************/
#include <string>

int menu(std::string[], int);