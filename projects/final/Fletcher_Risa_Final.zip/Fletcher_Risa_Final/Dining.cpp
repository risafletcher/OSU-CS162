/*******************************************************************************
** Author:       Risa Fletcher
** Date:         12/10/19
** Description:  A derived room class
*******************************************************************************/
#include "Dining.hpp"
#include "Space.hpp"
#include "Player.hpp"
#include <iostream>

using std::cin;
using std::cout;
using std::endl;

Dining::Dining() : Space()
{
    name = DINING;
}

Dining::Dining(Space *top, Space *right, Space *bottom, Space *left) : 
Space(top, right, bottom, left)
{}

void Dining::checkDiningChairs()
{
    cout << "You checked all of the chairs and found nothing." << endl;
}

void Dining::serveMelania(Player *player)
{
    if (player->hasItem(SALAD))
    {
        player->removeItem(SALAD);
        cout << "Melania is pleased. You show her the note. She complains ";
        cout << "about the president and admits to flushing the wig down the ";
        cout << "toilet." << endl;
    }
    else
    {
        cout << "You have nothing to serve." << endl;
    }
}

void Dining::showMenu(Player *player)
{
    string options[3] = {
        "Check dining chairs",
        "Serve Melania"};

    int menuChoice = menu(options, 2);

    switch (menuChoice)
    {
    case 0:
        checkDiningChairs();
    case 1:
        serveMelania(player);
    default:
        break;
    }
}
