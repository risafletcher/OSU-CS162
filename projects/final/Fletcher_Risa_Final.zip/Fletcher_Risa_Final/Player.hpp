/*******************************************************************************
** Author:       Risa Fletcher
** Date:         12/10/19
** Description:  A class for the player, which tracks their items and position
*******************************************************************************/
#ifndef PLAYER_HPP
#define PLAYER_HPP
#include "Space.hpp"
#include <string>

using std::string;

class Player
{
    private:
        Space *location;
        Item *items;
        int numberOfItems;
        bool hasWon;

    public:
        Player();
        Player(Space *);
        ~Player();
        Space *getLocation();
        Item *getItems();
        int getNumberOfItems();
        void addItem(Item);
        bool hasItem(Item);
        void removeItem(Item);
        void setHasWon(bool);
        bool getHasWon();
        void move(Space *);
};

#endif